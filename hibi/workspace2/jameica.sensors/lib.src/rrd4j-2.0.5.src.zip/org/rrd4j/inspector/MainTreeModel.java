/* ============================================================
 * Rrd4j : Pure java implementation of RRDTool's functionality
 * ============================================================
 *
 * Project Info:  http://www.rrd4j.org
 * Project Lead:  Mathias Bogaert (m.bogaert@memenco.com)
 *
 * (C) Copyright 2003, by Sasa Markovic.
 *
 * Developers:    Sasa Markovic
 *
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 */

package org.rrd4j.inspector;

import org.rrd4j.core.RrdDb;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.io.File;

class MainTreeModel extends DefaultTreeModel {
	private static final DefaultMutableTreeNode INVALID_NODE =
			new DefaultMutableTreeNode("No valid RRD file specified");

	private File file;

	MainTreeModel() {
		super(INVALID_NODE);
    }

	boolean setFile(File newFile) {
		try {
			file = newFile;
			RrdDb rrd = new RrdDb(file.getAbsolutePath(), true);
			try {
				DefaultMutableTreeNode root = new DefaultMutableTreeNode(new RrdNode(rrd));
				int dsCount = rrd.getRrdDef().getDsCount();
				int arcCount = rrd.getRrdDef().getArcCount();
				for (int dsIndex = 0; dsIndex < dsCount; dsIndex++) {
					DefaultMutableTreeNode dsNode =
							new DefaultMutableTreeNode(new RrdNode(rrd, dsIndex));
					for (int arcIndex = 0; arcIndex < arcCount; arcIndex++) {
						DefaultMutableTreeNode arcNode =
								new DefaultMutableTreeNode(new RrdNode(rrd, dsIndex, arcIndex));
						dsNode.add(arcNode);
					}
					root.add(dsNode);
				}
				setRoot(root);
			}
			finally {
				rrd.close();
			}
			return true;
		}
		catch (Exception e) {
			setRoot(INVALID_NODE);
			Util.error(null, e);
		}
		return false;
	}
}
